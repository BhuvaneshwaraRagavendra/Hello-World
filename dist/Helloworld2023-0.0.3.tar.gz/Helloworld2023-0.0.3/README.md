
# This is ony for sample
Import package
```
from mypackage import main
```

Print hello world
```
main.mypackage()
Hello World
'''
Print fun function
'''
mypackage.main.mypackage.fun()
This is fun Part
'''