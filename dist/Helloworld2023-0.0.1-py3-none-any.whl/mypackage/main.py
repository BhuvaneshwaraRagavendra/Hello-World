class Hello:
    def __init__(self) -> None:
        print("Hello World")
    def fun():
        print("This is fun Part")